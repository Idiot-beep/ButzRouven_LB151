/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ch.bbbaden.gluecksrad_rouven_butz_m151;

/**
 *
 * @author rouve
 */
public class Login {
    
    //Name aus DB lesen
    //private String name = Client.getName;
    
    public String Login (){
        
        return "";
    }
}
