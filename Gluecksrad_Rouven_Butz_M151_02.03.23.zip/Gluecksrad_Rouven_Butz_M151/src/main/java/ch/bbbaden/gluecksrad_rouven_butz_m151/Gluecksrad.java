/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ch.bbbaden.gluecksrad_rouven_butz_m151;

/**
 *
 * @author rouve
 */
public class Gluecksrad {
    
    private int rundenGespielt = 0;
    private int geldGewonnen = 0;
    private String[] sonderpreise;
    private boolean aussetzen = false;
    private boolean extraDreh = false;
    
    public void start() {
    
    }
    
    public String raten(){
    
        return "Test";
    }
    
    public void spielBeenden(){
    
    }
}
